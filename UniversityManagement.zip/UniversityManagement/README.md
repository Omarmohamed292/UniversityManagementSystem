# Campus Registry: University Management System

ASP.NET Core 8 MVC + Entity Framework Core + SQL Server.

## Features
- Full CRUD for **students**, **instructors** and **courses**, with search on each list
- Relational schema: Departments, Instructors, Students, Courses, Enrollments (see `Database/schema.sql`)
- Enroll and drop students on the student detail page

## Server-side validation and business rules
- Data annotations plus `IValidatableObject` (students must be 16+, no future hire/enrollment dates)
- Unique email for students and instructors; unique, normalized course code (e.g. `CS101`)
- A course's instructor must belong to the course's department
- An instructor with courses cannot switch department until the courses are reassigned
- A student cannot enroll twice in a course and can take at most 6 courses (`EnrollmentService`)
- Deleting an instructor un-assigns their courses; deleting a student or course removes its enrollments

## Run it
1. Install the .NET 8 SDK and SQL Server (LocalDB or full instance).
2. Edit `ConnectionStrings:UniversityDb` in `appsettings.json` if you are not using LocalDB.
3. `dotnet restore` then `dotnet run`
4. Open the URL shown in the terminal. The database is created and seeded on first launch.

To use EF migrations instead of `EnsureCreated()`:
`dotnet ef migrations add Initial` then `dotnet ef database update` (and remove the `EnsureCreated()` call in `Program.cs`).
